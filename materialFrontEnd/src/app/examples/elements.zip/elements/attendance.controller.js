(function() {
    'use strict';

    angular
        .module('app.examples.elements')
        .controller('AttendanceController', AttendanceController);

    /* @ngInject */
    function AttendanceController($rootScope, $stateParams, $http, $state, $scope, $interval, $mdSidenav, $mdToast, $filter, $mdDialog, $compile, Auth, ClassListService, AttendanceTableService) {
        var vm = this;
        vm.buttonClass = 'md-primary';
        vm.buttonHue = 'md-default';
        $scope.isOpen = true;
        vm.buttonDisabled = false;
        vm.determinateValue = 30;
        vm.determinateValue2 = 30;
        // alert(JSON.stringify($stateParams.item));
        $interval(intervalTriggered, 100, 0, true);


        ////////////////

        function intervalTriggered() {
            vm.determinateValue += 1;
            vm.determinateValue2 += 1.5;
            if(vm.determinateValue > 100) {
                vm.determinateValue = 30;
                vm.determinateValue2 = 30;
            }
        }
        $scope.openSidebar = function (id) {
            $mdSidenav(id).toggle();
        };
        function getClassList () {
            ClassListService.getClassList(classListCallSuccess);

        };
        function classListCallSuccess(json, status, headers, config) {
            $scope.classList = json.data;
        };
        function classListCallFailure(json, status, headers, config) {
            console.log("error receiving data");
        };
        var vm = this;

        ////////////////
        $scope.cardCounter = 0;
        $rootScope.$on('takeAttendanceEvent', function(event, args) {
            $scope.classId = args.classId;
            $scope.selectedDate = args.date;
            var className = args.classId.split("-")[0];
            var section = args.classId.split("-")[1];
            AttendanceTableService.getUsers('http://localhost:3000/api/attendance/create', className, section, new Date(args.date)).then(function(users){
                vm.userData = users.data;
                // alert(JSON.stringify(vm.userData));
                renderCreateCard();
            });

        });

        $rootScope.$on('viewAttendanceEvent', function(event, args) {
            $scope.classId = args.classId;
            var className = args.classId.split("-")[0];
            var section = args.classId.split("-")[1];
            var startDate = new Date(args.startDate);
            var endDate = new Date(args.endDate);
            var daysOfYear = [];
            for (var d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
              AttendanceTableService.getUsers('http://localhost:3000/api/attendance/retrieve/bydate', className, section, new Date(d)).then(function(users){
                var data = users.data;
                renderViewCard(data);
              });
            }

        });
        $scope.saveTable = function () {
    	    	var response = [];
    	    	var tempObj = {};
    	    	// alert(JSON.stringify($scope.resData));
    	    	for (var key in $scope.resData) {
    			  	if ($scope.resData.hasOwnProperty(key)) {
    			    	tempObj["id"] = key;
    			    	tempObj["details"] = {};
    			    	for (var innerKey in $scope.resData[key]){
    			    		// var temp = {};
    			    		tempObj["details"][innerKey] = $scope.resData[key][innerKey]+"";
    			    		// tempObj["details"].push(temp);
    			    	}
    			  	}
    			  	response.push(tempObj);
    			}

    	    $http({
    	            url: 'http://localhost:3000/api/attendance/save',
    	            method: "POST",
    	            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    	            data: $.param({"token": Auth.getToken(), "class": $scope.classId.split("-")[0], "section": $scope.classId.split("-")[1], "date": new Date($scope.selectedDate), "data": response})
    	            }).success(attendanceSaved).error(attendanceNotSaved);
    	    	// $scope.disabled=true;
    	    }
          function attendanceSaved(data) {
    	    	alert("Saved "+ JSON.stringify(data));
    	    };
    	    function attendanceNotSaved(data) {
    	    	alert("not saved "+data);
    	    }
        function renderCreateCard() {
          if (vm.userData) {
            $scope.resData = [];
            $scope.disabled = false;
            var attributeList = [];
            var tempObj = {};
            var typeList = {};
            var tableStr =  '<md-card flex="90" class="ng-scope md-cyan-theme flex-90">\
                                <div class="ng-scope">\
                                    <md-data-table-toolbar ng-hide="vm.selected.length || vm.filter.show">\
                                        <h2 class="md-title">TAKE ATTENDANCE</h2>\
                                    </md-data-table-toolbar>\
                                    <table id="table'+$scope.cardCounter+'" class="display table table-bordered table-striped table-hover">';
              vm.userData.forEach(function (data) {
                  if (data.type == "header") {
                    tableStr += '<thead>\
                      <tr>';
                      // alert("myah");
                      data.data.forEach(function (titleElement) {
                          tableStr += '<th>'+ titleElement.name +'</th>';
                          attributeList.push(titleElement.attribute);
                          typeList[titleElement.attribute] = titleElement.type;
                      });
                      tableStr += '</tr>';
                      tableStr +=	'</thead>';
                  }
                  else if (data.type == "value") {
                      tableStr += '<tbody>';
                      data.data.forEach(function (dataRow) {
                          $scope.resData[dataRow.uid] = {};
                          tableStr += '<tr id="'+dataRow.uid+'">';
                          attributeList.forEach(function (attribute) {
                              if (typeList[attribute] == "checkbox") {
                                    $scope.resData[dataRow.uid][attribute] = dataRow[attribute];
                                    tableStr += '<td><input type="checkbox" aria-label="t" ng-checked="'+dataRow[attribute]+'" ng-model="'+attribute+"_"+dataRow.uid+'" ng-click="checkBoxChanged(\''+attribute+"_"+dataRow.uid+'\' , '+attribute+"_"+dataRow.uid+', \'' +dataRow.uid+'\',\''+attribute+'\')" ng-disabled="disabled"></td>';
                              }
                              else {
                                  tableStr += '<td><span>'+ dataRow[attribute] +'</span></td>';
                              }
                          });

                          tableStr += '</tr>';
                      });
                  }
              });
              tableStr+='<md-button class="md-primary" ng-click="saveTable()">Save</md-button>\
              <md-button ng-click="">Cancel</md-button>';
              tableStr += '</tbody>';
              tableStr += '</table>';
              tableStr += '</div>';
              tableStr += '</md-card>';
          }
          $scope.cardCounter+=1;
          var st = document.getElementById('attendanceCardsOuterDiv');
          st.innerHTML =  tableStr;
          $compile(st)($scope);
        }

        $scope.resData = {};
	      $scope.checkBoxChanged = function (model, state, id, attr) {
	    	    $scope.resData[id][attr] = state;
            // alert(model+", "+state+", "+id+", "+ attr);

        };

        function renderViewCard(datas) {
          var heading = "View Attendance";
          var str = "";
          var attributeList = [];
    			var tempObj = {};
    	    var typeList = {};
          $scope.viewDisabled = true;
          // alert(JSON.stringify(datas));
          if (datas) {
            var tableStr =  '<md-card flex="90" class="ng-scope md-cyan-theme flex-90">\
                                <div class="ng-scope">\
                                    <md-data-table-toolbar ng-hide="vm.selected.length || vm.filter.show">\
                                        <h2 class="md-title">VIEW ATTENDANCE</h2>\
                                    </md-data-table-toolbar>\
                                    <table id="table'+$scope.cardCounter+'" class="display table table-bordered table-striped table-hover">';
              datas.forEach(function (data) {
                if (data.type == "header") {
                    tableStr += '<thead>\
                      <tr>';
                      data.data.forEach(function (titleElement) {
                          tableStr += '<th>'+ titleElement.name +'</th>';
                          attributeList.push(titleElement.attribute);
                          typeList[titleElement.attribute] = titleElement.type;
                      });
                      tableStr += '</tr>';
                      tableStr +=	'</thead>';
                  }
                  else if (data.type == "value") {
                    // alert("here");
                      tableStr += '<tbody>';
                      data.data.forEach(function (dataRow) {
                          $scope.resData[dataRow.uid] = {};
                          tableStr += '<tr id="'+dataRow.uid+'">';
                          attributeList.forEach(function (attribute) {
                              if (typeList[attribute] == "checkbox") {
                                    $scope.resData[dataRow.uid][attribute] = dataRow[attribute];
                                    tableStr += '<td><input type="checkbox" aria-label="t" ng-checked="'+dataRow[attribute]+'" ng-model="'+attribute+"_"+dataRow.uid+'" ng-click="checkBoxChanged(\''+attribute+"_"+dataRow.uid+'\' , '+attribute+"_"+dataRow.uid+', \'' +dataRow.uid+'\',\''+attribute+'\')" ng-disabled="viewDisabled"></td>';
                              }
                              else {
                                  tableStr += '<td><span>'+ dataRow[attribute] +'</span></td>';
                              }
                          });

                          tableStr += '</tr>';
                      });
                  }
              });
              tableStr += '</tbody>';
              tableStr += '</table>';
              tableStr += '</div>';
              tableStr += '</md-card>';
	        }

        var st = document.getElementById('viewAttendanceCardsOuterDiv');
        st.insertAdjacentHTML('afterbegin', tableStr);
        $compile(st)($scope);
        }


        $scope.callFABAction = function ($event, type, state, templateUrl, controller) {
            // alert(JSON.stringify($stateParams.item));
            $state.go(state, {item:$stateParams.item});
            $mdDialog.show({
                controller: controller,
                controllerAs: 'vm',
                templateUrl: templateUrl,
                locals: {
                    range: vm.dateRange
                },
                targetEvent: $event
            })
            .then(function() {
                $mdToast.show(
                    $mdToast.simple()
                    .content($filter('translate')('Action Selected'))
                    .position('bottom right')
                    .hideDelay(2000)
                );
            });
        }

        getClassList();

        var vm = this;
        vm.buttonClass = 'md-primary';
        vm.buttonHue = 'md-default';

        vm.buttonDisabled = false;
        vm.determinateValue = 30;
        vm.determinateValue2 = 30;
        $interval(intervalTriggered, 100, 0, true);

        ////////////////

        function intervalTriggered() {
            vm.determinateValue += 1;
            vm.determinateValue2 += 1.5;
            if(vm.determinateValue > 100) {
                vm.determinateValue = 30;
                vm.determinateValue2 = 30;
            }
        }
        var vm = this;
        vm.dateRange = {
            start: moment().startOf('week'),
            end: moment().endOf('week')
        };

        vm.query = {
            order: 'date',
            limit: 5,
            page: 1
        };
        $scope.fabButtonList = [{
            label: 'Create',
            name: 'create',
            state: 'triangular.admin-default.attendance.content',
            icon: 'zmdi zmdi-plus',
            class: 'md-fab md-raised md-mini md-primary',
            function: 'callFABAction',
            templateUrl: 'app/examples/elements/createAttendance.dialog.html',
            controller: 'createAttendanceDialogController'
        },
        {
            label: 'View',
            name: 'view',
            state: 'triangular.admin-default.attendance.view',
            icon: 'zmdi zmdi-eye',
            class: 'md-fab md-raised md-mini md-primary',
            function: 'callFABAction',
            templateUrl: 'app/examples/elements/viewAttendance.dialog.html',
            controller: 'ViewAttendanceDialogController'
        },
        {
            label: 'Edit',
            name: 'edit',
            state: 'triangular.admin-default.attendance.content',
            icon: 'zmdi zmdi-edit',
            class: 'md-fab md-raised md-mini md-primary',
            function: 'callFABAction',
            templateUrl: 'app/examples/dashboards/sales/date-change-dialog.tmpl.html'
        },
        {
            label: 'Delete',
            name: 'delete',
            state: 'triangular.admin-default.attendance.content',
            icon: 'zmdi zmdi-delete',
            class: 'md-fab md-raised md-mini md-primary',
            function: 'callFABAction',
            templateUrl: 'app/examples/dashboards/sales/date-change-dialog.tmpl.html'
        }
        ];

        $scope.callFunction = function (name, param, type, state, templateUrl, controller) {
            if(angular.isFunction($scope[name])) {
                $scope[name](param, type, state, templateUrl, controller);
            }
        }
    }
})();
