(function() {
    'use strict';

    angular
        .module('app.examples.dashboards')
        .controller('createAttendanceDialogController', createAttendanceDialogController)
        .controller('ViewAttendanceDialogController', ViewAttendanceDialogController);

    /* @ngInject */
    function createAttendanceDialogController($rootScope, $scope, $mdDialog, $stateParams, range, ClassListService) {
        var vm = this;
        vm.cancelClick = cancelClick;
        vm.okClick = okClick;
        $scope.classList = [];
        $scope.state_class = $stateParams.item;
        ClassListService.getClassList(classListCallSuccess);
        ////////////////

        function classListCallSuccess(json, status, headers, config) {
            $scope.classList = json.data;
        };
        function okClick() {
            range.start = new moment(vm.start);
            range.end = new moment(vm.end);
            $mdDialog.hide();
            $rootScope.$emit('takeAttendanceEvent', {date:range.start, classId:$scope.classId});
        }

        function cancelClick() {
            $mdDialog.cancel();
        }

        // init

        vm.start = range.start.toDate();
    }
    function ViewAttendanceDialogController($rootScope, $scope, $mdDialog, $stateParams, range, ClassListService) {
        var vm = this;
        vm.cancelClick = cancelClick;
        vm.okClick = okClick;
        $scope.classList = [];
        $scope.state_class = $stateParams.item;
        ClassListService.getClassList(classListCallSuccess);
        ////////////////

        function classListCallSuccess(json, status, headers, config) {
            $scope.classList = json.data;
        };
        function okClick() {
            range.start = new moment(vm.start);
            range.end = new moment(vm.end);
            $mdDialog.hide();
            $rootScope.$emit('viewAttendanceEvent', {startDate: range.start, endDate: range.end, classId:$scope.classId});
        }

        function cancelClick() {
            $mdDialog.cancel();
        }

        // init

        vm.start = range.start.toDate();
        vm.end = range.start.toDate();
    }
})();
