(function() {
    'use strict';

    angular
        .module('app.examples.elements')
        .controller('marksController', marksController)
        .controller('MarksContentController', MarksContentController)
        .controller('MarksCreateController', MarksCreateController)
        .factory('ExamListService', function($http, Auth) { // the service needs to be upgraded to be called only once.
            return {
              getExamList: function(callback, id) {
                $http({
                  url: 'http://localhost:3000/api/marks/examlist',
                  method: "POST",
                  data: $.param({token: Auth.getToken(), class:id.split("-")[0], section: id.split("-")[1]}),
                  headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                }).success(callback).error(function (data) {
                  console.log(data);
                });
              }
            }
        });

    /* @ngInject */
    function marksController($rootScope, $stateParams, $http, $state, $scope, $interval, $mdSidenav, $mdToast, $filter, $mdDialog, $compile, Auth, ExamListService, ClassListService, AttendanceTableService) {
        var classSection = "";
        var vm = this;
        vm.buttonClass = 'md-primary';
        vm.buttonHue = 'md-default';
        $scope.isOpen = true;
        vm.buttonDisabled = false;
        vm.determinateValue = 30;
        vm.determinateValue2 = 30;
        $interval(intervalTriggered, 100, 0, true);


        ////////////////

        function intervalTriggered() {
            vm.determinateValue += 1;
            vm.determinateValue2 += 1.5;
            if(vm.determinateValue > 100) {
                vm.determinateValue = 30;
                vm.determinateValue2 = 30;
            }
        }
        $scope.getRightSidebar = function (id, id1) {
            classSection = id;
            getExamList(id);
            $mdSidenav(id1).toggle();

        };
        $scope.openSidebar = function (id) {
            $mdSidenav(id).toggle();

        };
        function getClassList () {
            ClassListService.getClassList(classListCallSuccess);
        };
        function getExamList (id) {
            ExamListService.getExamList(examListCallSuccess, id);
        };

        $scope.createMarks = function () {
          // alert($stateParams.item);
          $state.go('triangular.admin-default.marks.new', {item: classSection});
        };
        $scope.closeSideBars = function(){
          $mdSidenav('example-right').toggle();
          $mdSidenav('example-left').toggle();
        }
        function examListCallSuccess(json, status, headers, config) {
          console.log("data:"+JSON.stringify(json.data))
          $scope.examList = json.data;
        }
        function classListCallSuccess(json, status, headers, config) {
            $scope.classList = json.data;
        };
        function classListCallFailure(json, status, headers, config) {
            console.log("error receiving data");
        };
        var vm = this;

        ////////////////
       getClassList();
    }

    function MarksContentController($http, $scope, $stateParams, Auth, $compile){
      var exam_id = $stateParams.exam;
      $scope.exam_class = $stateParams.class;
      $scope.exam_section = $stateParams.section;
      $http({
                  url: 'http://localhost:3000/api/marks/view',
                  method: "POST",
                  data: $.param({token: Auth.getToken(), id:exam_id}),
                  headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                }).success(function(data){
                  displayTable(data);
                }).error(function (err) {
                  console.log(err);
                });    
      function displayTable(data){
        $scope.exam_name = data.data.name;
        $scope.exam_date = data.data.date.split('T')[0];
        var length1 = data.data.subjects.length;
        var a = '<thead><tr><th>Name</th><th>Roll Number</th>';
        for(var i=0;i<length1;i++)
        {
          a += '<th>'+data.data.subjects[i]+'</th>'
        }
        a += '</tr></thead>';
        a += '<tbody>';
        var length2 = data.marks.length;
        for(var i=0;i<length2;i++)
        {
          a += '<tr><td>'+data.marks[i].name+'</td><td>'+data.marks[i].rollno+'</td>';
          for(var j=0;j<length1;j++)
          {
            a += '<td>'+data.marks[i].score[j]+'</td>';
          }
          a += '</tr>';
        }
        a += '</tbody>';
        $('#table4').html(a);
        $compile(document.getElementById('table4'))($scope)
      }              
    }
    function MarksCreateController($scope, $http, $stateParams, Auth)
    {
      var user_class = $stateParams.item.split('-')[0];
      var user_section = $stateParams.item.split('-')[1];
      console.log(user_class)
      console.log(user_section)
      $http({
        url: 'http://localhost:3000/api/users/specific',
        method: "POST",
        data: $.param({token: Auth.getToken(), class:user_class, section: user_section, role: 'Admin'}),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'}
      }).success(function(data){
        console.log(data);
      }).error(function(err){
        console.log(err);
      });
    }
})();
