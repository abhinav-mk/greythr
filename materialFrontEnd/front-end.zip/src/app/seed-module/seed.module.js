(function() {
    'use strict';

    angular
        .module('seed-module', [
        ]);
})();