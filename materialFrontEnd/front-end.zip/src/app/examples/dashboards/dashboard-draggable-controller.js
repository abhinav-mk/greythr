(function() {
    'use strict';

    angular
        .module('app.examples.dashboards')
        .controller('DashboardDraggableController', DashboardDraggableController);

    /* @ngInject */
    function DashboardDraggableController() {
    }
})();
