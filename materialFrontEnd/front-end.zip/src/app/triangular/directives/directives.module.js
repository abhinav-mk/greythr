(function() {
    'use strict';

    angular
        .module('triangular.directives', [
        ]);
})();