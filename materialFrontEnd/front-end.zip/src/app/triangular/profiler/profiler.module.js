(function() {
    'use strict';

    angular
        .module('triangular.profiler', [
            'digestHud'
        ]);
})();