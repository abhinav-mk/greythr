(function() {
    'use strict';

    angular
        .module('triangular.components', [
        ]);
})();