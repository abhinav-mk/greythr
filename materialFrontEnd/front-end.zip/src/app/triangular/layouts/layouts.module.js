(function() {
    'use strict';

    angular
        .module('triangular.layouts', [

        ]);
})();