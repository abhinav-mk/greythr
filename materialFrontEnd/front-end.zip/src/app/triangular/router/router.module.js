(function() {
    'use strict';

    angular
        .module('triangular.router', [

        ]);
})();